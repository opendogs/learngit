//index.js
const app = getApp()

Page({
  data: {
    avatarUrl: './user-unlogin.png',
    userInfo: {},
    logged: false,
    takeSession: false,
    requestResult: '',
    
      
    

  },

  onLoad: function (options) {
    var thats = this;
    
    wx.request({
      url: 'https://ichantu.com/site/list.html', //仅为示例，并非真实的接口地址
      method: "POST",
      header: {
        //传输接收数据的头（！！！）
        'content-type': 'application/x-www-form-urlencoded;charset=utf-8'
      },
     

      success: function (res) {
        var arr = res.data
        
        // console.log(res.data);

        if (arr) {
          thats.setData({
            datalist: arr,
          })
        }
        
      }
    })

   
  },

  onGetUserInfo: function(e) {
    if (!this.logged && e.detail.userInfo) {
      // this.setData({
      //   logged: true,
      //   avatarUrl: e.detail.userInfo.avatarUrl,
      //   userInfo: e.detail.userInfo
      // })
    }
  },

  onGetOpenid: function() {
    // 调用云函数
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        app.globalData.openid = res.result.openid
        wx.navigateTo({
          url: '../userConsole/userConsole',
        })
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  // 上传图片
  doUpload: function () {
    // 选择图片
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {

        wx.showLoading({
          title: '上传中',
        })

        const filePath = res.tempFilePaths[0]
        
        // 上传图片
        const cloudPath = 'my-image' + filePath.match(/\.[^.]+?$/)[0]
        wx.cloud.uploadFile({
          cloudPath,
          filePath,
          success: res => {
            console.log('[上传文件] 成功：', res)

            app.globalData.fileID = res.fileID
            app.globalData.cloudPath = cloudPath
            app.globalData.imagePath = filePath
            
            wx.navigateTo({
              url: '../storageConsole/storageConsole'
            })
          },
          fail: e => {
            console.error('[上传文件] 失败：', e)
            wx.showToast({
              icon: 'none',
              title: '上传失败',
            })
          },
          complete: () => {
            wx.hideLoading()
          }
        })

      },
      fail: e => {
        console.error(e)
      }
    })
  },
  /**
   * 跳转到个库
   */
  jumpGeku: function (e) {
    
    var uid = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '../geku/geku?id='+uid,
    })
  },
  /**
   * 跳转到企推
   */
  jumpQitui: function (e) {

    var uid = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '../qitui/qitui',
    })
  },
  ceshi: function(){
    wx.request({
      url: 'https://ichantu.com/index.php', //仅为示例，并非真实的接口地址
      method: "POST",
      header: {
        //传输接收数据的头（！！！）
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        x: 'x'
      },

      success: function (res) {
        console.log(res.data)
        if (res.data ==='[object Undefined]') {
          that.data.isCode = true
          wx.showToast({
            title: '啥也没有',
            icon: 'success',
            duration: 2000
          })
        } else {
          wx.showToast({
            title: '答对了',
            icon: 'success',
            duration: 2000
          })
        }
      }
    })

  },
  // 获取用户信息
  getUserInfo: function (e) {
  wx.getSetting({
    success: res => {
      if (res.authSetting['scope.userInfo']) {
        // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
        var thats = this
        
        wx.getUserInfo({
          success: function (res) {
            
            var id = getApp().globalData.id;

            var iocn = res.userInfo.avatarUrl;
            var nickname = res.userInfo.nickName;
            
            console.log(res.userInfo.avatarUrl);
            console.log(res.userInfo.nickName);
            getApp().globalData.iocn = res.userInfo.avatarUrl;
            getApp().globalData.nickName = res.userInfo.nickName;
            // getApp().globalData.id = res.data.id
            // that.setData({
            //   [avatarUrl]: res.userInfo.avatarUrl,
            //   [nickName]: res.userInfo.nickName,
            // })
            // wx.request({
            //   url: 'https://ichantu.com/site/adduser.html',
            //   method: "POST",
            //   header: {
            //     //传输接收数据的头（！！！）
            //     "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

            //   },
            //   data: {
            //     iocn: iocn,
            //     id: id,
            //     nickname: nickname,

            //     miniid: 1
            //   },

            //   success: function (res) {
            //     // console.log(res)
            //     wx.request({
            //       url: 'https://ichantu.com/site/list.html', //仅为示例，并非真实的接口地址
            //       method: "POST",
            //       header: {
            //         //传输接收数据的头（！！！）
            //         'content-type': 'application/x-www-form-urlencoded;charset=utf-8'
            //       },


            //       success: function (res) {
            //         var arr = res.data
            //         console.log(res.data);

            //         if (arr) {
            //           thats.setData({
            //             datalist: arr,
            //           })
            //         }

            //       }
            //     })

            //   }
            // })
          }
        })
      }
    }
  })
  },
  getSetting: function (e) {
    console.log(e.detail.errMsg)
    console.log(e.detail.userInfo)
    console.log(e.detail.rawData)
  },
  login:function(){
    wx.login({
      success(res) {
        if (res.code) {
          //发起网络请求
          wx.request({
            url: 'https://ichantu.com/index.php',
            data: {
              code: res.code
            },
            success: function (data){
              wx.showModal({
                title: '提示',
                content: res.data,
                success: function (res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                  } else if (res.cancel) {
                    console.log('用户点击取消')
                  }
                }
              })
              console.log(data);
              console.log("===data===" + JSON.stringify(res.data));
              
            }
          })
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
  },
//跳转到企业注册
  jumpRegister: function (e) {
    wx.navigateTo({
      url: '../register/register',
    })
  },



  jumpSign: function () {
    wx.navigateTo({
      url: '../sign/sign',
    })
  },



  //滑动获取选中首页新企业
  getSelectItem: function (e) {
    var that = this;
    var itemWidth = e.detail.scrollWidth / that.data.proList.length;//每个企业的宽度
    var scrollLeft = e.detail.scrollLeft;//滚动宽度
    var curIndex = Math.round(scrollLeft / itemWidth);//通过Math.round方法对滚动大于一半的位置进行进位
    for (var i = 0, len = that.data.proList.length; i < len; ++i) {
      that.data.proList[i].selected = false;
    }
    that.data.proList[curIndex].selected = true;
    that.setData({
      proList: that.data.proList,
      giftNo: this.data.proList[curIndex].id
    });
  },



//跳转
  jumpbk: function (e) {
    wx.navigateTo({
      url: '../bk/bk'
    })
  }


})
