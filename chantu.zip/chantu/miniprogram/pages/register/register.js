// pages/register/register.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   *跳转登录页面
   */
  jumpSign: function () {
    wx.navigateTo({
      url: '../sign/sign',
    })
  },
/**
 * 注册
 */
  addUser:function(e){
    var id = getApp().globalData.id//id
    var name = e.detail.value.name//名字
    var phone = e.detail.value.phone//
    var pwd = e.detail.value.pwd//名字
    // var type = e.detail.value.type//名字
  
    if (name == ""){
      wx.showToast({
        title: '请填写名字',
        icon: 'none',
        duration: 2000
      })
      return
    }
    if (phone == "") {
      wx.showToast({
        title: '请填写手机号',
        icon: 'none',
        duration: 2000
      })
      return
    }
    if (pwd == "") {
      wx.showToast({
        title: '请填写密码',
        icon: 'none',
        duration: 2000
      })
      return
    }
   
    wx.request({
      url: 'https://ichantu.com/site/enterprise.html',
      method: "POST",
      header: {
        //传输接收数据的头（！！！）
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

      },
      data: {
        uid: id,
        name: name,
        phone: phone,
        pwd: pwd,

      },
      success: function (res) {

        var arr = res.data
        console.log(arr);
        return
        // console.log(thats);
        // if (res) {
        //   thats.setData({
        //     datalist: arr
        //   })
        // wx.navigateTo({
        //   url: '../card/detailscard?cid=' + data.id,//跳转到我添加的名片页面
        // })
        // }
      }
    })
    // console.log(e);
    // return
    
  },
 


  data: {
    sex: 0,
    radios: [
      {
        label: '企业',
        value: '企业',
      },
      {
        label: '实体店',
        value: '实体店',
      },
      {
        label: '微品牌',
        value: '微品牌',
      },
    ]
  },
  check(e) {
    console.log(e)
    var that = this;
    var sex = e.currentTarget.dataset.index
    that.setData({
      sex: sex
    })
  }


})

