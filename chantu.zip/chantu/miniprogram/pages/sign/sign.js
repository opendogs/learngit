// pages/sign/sign.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

<<<<<<< .mine
  },
  /**
   * 登录
   */
  sign: function (e) {
    var pwd = e.detail.value.pwd//名字
    var name = e.detail.value.name//
    wx.request({
      url: 'https://ichantu.com/site/enterprisesign.html',
      method: "POST",
      header: {
        //传输接收数据的头（！！！）
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

      },
      data: {
        // uid: id,
        name: name,
        pwd: pwd,

      },
      success: function (res) {

        var arr = res.data
        console.log(arr);
        return
        // console.log(thats);
        // if (res) {
        //   thats.setData({
        //     datalist: arr
        //   })
        // wx.navigateTo({
        //   url: '../card/detailscard?cid=' + data.id,//跳转到我添加的名片页面
        // })
        // }
      }
    })
    console.log(e);
    return
||||||| .r4575
=======
  },
  
  
  //跳转到企业注册
  jumpRegister: function (e) {
    wx.navigateTo({
      url: '../register/register',
    })
>>>>>>> .r4617
  }

})