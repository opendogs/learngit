// pages/card/card.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name:' ',
    nickname: ' ',
    openid: ' ',
    position: ' ',
    phone: ' ',
    email: ' ',
    cname:' ',
    caddress: ' ',
    statr: ' ',
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    
    if (options.id) {
      var uid = options.id
      wx.request({
        url: 'https://ichantu.com/site/user.html',
        method: "POST",
        header: {
          //传输接收数据的头（！！！）
          "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

        },
        data: {
          id: uid,

        },
        success: function (res) {
          console.error(res.data.id)
          that.setData({
            id: res.data.id,
            name: res.data.name,
            nickname: res.data.nickname,
            openid: res.data.openid,
            position: res.data.position,
            phone: res.data.phone,
            email: res.data.email,
            cname: res.data.cname,
            caddress: res.data.caddress,
            statr: res.data.statr,
            iocn: res.data.iocn,
          });

        }
      })
    } else {
      that.setData({
        name: app.globalData.name,
        nickname: app.globalData.nickname,
        openid: app.globalData.openid,
        position: app.globalData.position,
        phone: app.globalData.phone,
        email: app.globalData.email,
        cname: app.globalData.cname,
        caddress: app.globalData.caddress,
        statr: app.globalData.statr,
        id: app.globalData.id,
      });
      var uid = app.globalData.id
      wx.request({
        url: 'https://ichantu.com/site/browse.html',
        method: "POST",
        header: {
          //传输接收数据的头（！！！）
          "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

        },
        data: {
          id: uid,

        },
        success: function (res) {

          var arr = res.data.browse
          var numbers = res.data.numbers
          console.log(arr);

          if (res) {
            that.setData({
              datalist: arr,
              numbers: numbers,
            })
          }
        }
      })
    }
    // console.log(res.data)
    
    // console.log('zaizhe')
    // this.setData({
    //   name: app.globalData.name,
    //   nickname: app.globalData.nickname,
    //   openid: app.globalData.openid,
    //   position: app.globalData.position,
    //   phone: app.globalData.phone,
    //   email: app.globalData.email,
    //   cname: app.globalData.cname,
    //   caddress: app.globalData.caddress,
    //   statr: app.globalData.statr,
    //   id: app.globalData.id,
    // });  //全局方法的执行
    wx.request({
      url: 'https://ichantu.com/site/cardfind.html',
      method: "POST",
      header: {
        //传输接收数据的头（！！！）
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

      },
      data: {
        openid: app.globalData.openid,
        
      },
      success: function (res) {
        // console.log(res)
        if (res==0){
          that.setData({
            create_time:'未设置',
          });
        }else{
          that.setData({
            create_time: res.data,
          });
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  //跳转到首页
  jumpIndex: function () {
    wx.navigateTo({
      url: '../index/index',
    })
  },
  //跳转到个库
  jumpGeku: function () {
    wx.navigateTo({
      url: '../geku/geku',
    })
  },
  //跳转到企推
  jumpQitui: function () {
    wx.navigateTo({
      url: '../qitui/qitui',
    })
  },
  //跳转到编辑名片
  jumpBjcard: function () {
    wx.navigateTo({
      url: '../card/bjcard',
    })
  },
  //跳转到私有名片
  jumpBscard: function () {
    wx.navigateTo({
      url: '../card/bscard',
    })
  },
  //交换名片跳转
  jumpNew: function (options) {
    wx.navigateTo({
      url: '../new/new',
    })

  },
  /**
   * 互换卡片
   */
  Change: function (options) {
    // console.log(app.globalData.id)
    // console.log(options.currentTarget.id)
    var id = app.globalData.id
    var cid = options.currentTarget.id
    if(id==cid){
      wx.showToast({
        title: '不支持自我交换',
        icon: 'none',
        duration: 2000
      })
      return
    }
    wx.request({
      url: 'https://ichantu.com/site/exchange.html',
      method: "POST",
      header: {
        //传输接收数据的头（！！！）
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

      },
      data: {
        id: app.globalData.id,
        cid:options.currentTarget.id,
      },
      success: function (res) {
        console.log(res.data)
        if (res.data ==1 ) {
          wx.showToast({
            title: '交换成功',
            icon: 'success',
            duration: 2000
          })
        } else if (res.data ==2) {
          wx.showToast({
            title: '该卡片已存在',
            icon: 'none',
            duration: 2000
          })
        }else{
          wx.showToast({
            title: '交换失败',
            icon: 'none',
            duration: 2000
          })
        }
      }
    })
    // wx.navigateTo({
    //   url: '../new/new',
    // })

  },
  /**
   * 填写名片资料
   */
  addCard: function () {
    wx.navigateTo({
      url: '../card/addcard',
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  // /**
  //  * 生命周期函数--监听页面卸载
  //  */
  // onUnload: function () {

  // },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    // if (res.from === 'button') {
    //   // 来自页面内转发按钮
    //   console.log(res.target)
    // }
    var id=app.globalData.id
    return {
      title: '自定义转发标题',
      path: 'pages/card/card?id='+id,
      complete: function (res) {
        // 转发失败
        console.error(res)
      }
    }

  }
})