// pages/card/bscard.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    datalist: []

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var thats = this;
    var id = getApp().globalData.id
    var openid=getApp().globalData.openid;
    // console.log(openid);
    wx.request({
      url: 'https://ichantu.com/card/index.html',
      method: "POST",
      header: {
        //传输接收数据的头（！！！）
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

      },
      data: {
        id: id,

      },
      success: function (res) {
        
        var arr=res.data
        console.log(arr);
        
        if (res){
          thats.setData({
            datalist: arr,
            openid: openid
          })
        }
       }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  /**
   * 查看自己添加或者交换的名片
   */
  jumpTjcard: function (options) {
    console.log(options)
    var cid = options.currentTarget.id
    var category = options.currentTarget.dataset.type
    if (category==1){
      wx.navigateTo({
        url: '../card/tjcard?cid=' + cid,//跳转到我添加的名片页面
      })
    }else{
      wx.navigateTo({
        url: '../card/detailscard?cid=' + cid,//跳转到我交换的名片页面
      })
    }
    



  },
  //跳转到我的名片
  jumpCard: function () {
    wx.navigateTo({
      url: '../card/card',
    })
  },
  //添加名片跳转
  addPrcard: function (options) {
    
      wx.navigateTo({
        url: '../card/praddcard',
      })
   


  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})