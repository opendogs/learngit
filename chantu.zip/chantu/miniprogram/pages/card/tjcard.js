// pages/card/tjcard.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this
    if (options.cid) {
      var cid = options.cid
        // console.log(options)
        wx.request({
          url: 'https://ichantu.com/card/carddata.html',
          method: "POST",
          header: {
            //传输接收数据的头（！！！）
            "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

          },
          data: {
            id: cid,

          },
          success: function (res) {
            console.log(res)
            if(res.data==0){
              
              wx.showToast({
                title: '暂无数据',
                icon: 'none',
                duration: 2000
              })
            }else{
              that.setData({
                id: res.data.id,
                name: res.data.name,
                // nickname: res.data.nickname,
                // openid: res.data.openid,
                position: res.data.resign,
                phone: res.data.phone,
                email: res.data.email,
                cname: res.data.cname,
                caddress: res.data.address,
                statr: res.data.statr,
                iocn: res.data.iocn,
              });
            }
          }
        })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})