// pages/card/bjcard.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this
    var id = getApp().globalData.id
    wx.request({
      url: 'https://ichantu.com/site/getcard.html',
      method: "POST",
      header: {
        //传输接收数据的头（！！！）
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

      },
      data: {
        id: id,
        
      },
      success: function (res) {
        that.setData({
          data: res.data,
        })
        
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 添加用户自己的名片
   */
  addCard: function (e) {
    var data = JSON.stringify(e.detail.value)
    var name = e.detail.value.name//名字
    var phone = e.detail.value.phone//手机号
    var cname = e.detail.value.cname//企业名字
    var position = e.detail.value.position//企业职位
    var caddress = e.detail.value.caddress//地址
    var email = e.detail.value.email//邮箱
    var business = e.detail.value.business//主营业务
    
    // var data = e.detail.value
    // data = json_decode(data)
    var id = getApp().globalData.id
    var iocn = getApp().globalData.iocn
    var openid = getApp().globalData.openid
    console.log(data);
    if (data === 0 || data == null) {
      wx.showToast({
        title: '数据为空，请填写数据',
        icon: 'none',
        duration: 2000
      })
    }
    if (name == null) {
      console.log(name)
      wx.showToast({
        title: '姓名不能为空，请填写数据',
        icon: 'none',
        duration: 2000
      })
    }
    if (phone == null) {
      console.log(name)
      wx.showToast({
        title: '手机号不能为空，请填写数据',
        icon: 'none',
        duration: 2000
      })
    }
    wx.request({
      url: 'https://ichantu.com/site/updatacard.html',
      method: "POST",
      header: {
        //传输接收数据的头（！！！）
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

      },
      data: {
        id: id,
        iocn: iocn,
        data: data,
        name: name,
        phone: phone,
        cname: cname,
        openid: openid,
        position: position,//企业职位
        caddress: caddress,//地址
        email: email,//邮箱
        business: business,//主营业务
      },
      success: function (res) {
        if (res.data ==1) {
          wx.showToast({
            title: '创建成功',
            icon: 'success',
            duration: 2000
          })

          getApp().globalData.name = name
          getApp().globalData.position = position
          getApp().globalData.phone = phone
          getApp().globalData.email = email
          getApp().globalData.cname = cname
          getApp().globalData.caddress = caddress
          getApp().globalData.business = business
          getApp().globalData.statr = 1
          wx.navigateTo({
            url: '../card/card',
          })
        } else {
          console.log(res.data);
          wx.showToast({
            title: '创建失败',
            icon: 'none',
            duration: 2000
          })
        }

      }
      // const that = this;
      // let first, second;
      // that.setData({
      //   data:e.detail.value.name
      // })
    })

  }
})