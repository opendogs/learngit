// pages/card/addcard.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 添加用户自己的名片
   */
  addCard: function (e) {
    var data=JSON.stringify(e.detail.value)
    var name = e.detail.value.name//名字
    var phone= e.detail.value.phone//手机号
    var cname = e.detail.value.cname//企业名字
    var position = e.detail.value.position//企业职位
    var caddress = e.detail.value.caddress//地址
    var email = e.detail.value.email//邮箱
    var business = e.detail.value.business//主营业务
    // var data = e.detail.value
    // data = json_decode(data)
    var createid = getApp().globalData.id
    console.log(createid)
    if (data===0||data==null){
      wx.showToast({
        title: '数据为空，请填写数据',
        icon: 'none',
        duration: 2000
      })
    }
    if (name ==null){
      console.log(name)
      wx.showToast({
        title: '姓名不能为空，请填写数据',
        icon: 'none',
        duration: 2000
      })
    }
    if (phone == null) {
      
      wx.showToast({
        title: '手机号不能为空，请填写数据',
        icon: 'none',
        duration: 2000
      })
    }
    wx.request({
      url: 'https://ichantu.com/site/addprcard.html',
      method: "POST",
      header: {
        //传输接收数据的头（！！！）
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"

      },
      data: {
        data: data,
        name:name,
        phone: phone,
        cname: cname,
        createid: createid,
        position:position,//企业职位
        caddress: caddress,//地址
        email:email,//邮箱
        business:business,//主营业务
      },
      success: function (res) {
        
        if (res.data==1){
          console.log(res)
          wx.showToast({
            title: '添加成功',
            icon: 'success',
            duration: 2000
          })
          wx.navigateTo({
            url: '../card/bscard',
          })
        }else{
          console.log(res)
          wx.showToast({
            title: '添加失败',
            icon: 'none',
            duration: 2000
          })
        }
        
      }
    // const that = this;
    // let first, second;
    // that.setData({
    //   data:e.detail.value.name
    // })
    })
    
  }
})